package com.freshlms.sterDefinatiions.ui;

import com.freshlms.ui.utils.Selenium_Utils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.freshlms.ui.utils.Excel_Utils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class MyStepdefs {

    @Given("validate project structure")
    public void validateProjectStructure() {
        System.out.print("Step 1 Verified");

    }

    @And("Verify the status")
    public void verifyTheStatus() {
        System.out.print("Step 2 Verified");
    }

    @And("Launch browser")
    public void launchBrowser() {
        try{
            read_excel();

            System.out.print("Browser Launched");
        }
        catch (Exception e){

        }


    }

    public  void read_excel() throws IOException {
        String path="C:\\Users\\mkiran8\\Desktop\\Freshlms\\Demo.xlsx";
        XSSFWorkbook wb;
        try{
            FileInputStream inputStream=new FileInputStream(path);

             wb=new XSSFWorkbook(inputStream);
            XSSFSheet sheet=wb.getSheet("Sheet1");
//            //Getting no.of columns
//            XSSFRow row=sheet.getRow(0);
//            int colum_count=row.getLastCellNum();
//            //System.out.println(colum_count);
//            XSSFCell cell=null;
//            //Getting Column Names
//            for (int i=0;i<colum_count;i++){
//                cell=row.getCell(i);
//                String column_name=cell.getStringCellValue();
//
//                System.out.print("Column Name is "+column_name);

                XSSFRow row=null;
                XSSFCell cell=null;
                String col1=null;
                String col2=null;
                String col2_Value="Write to Excel";
                for (int i=1;i<=sheet.getLastRowNum();i++) {
                    row=sheet.getRow(i);

                    for (int j=0;j<row.getLastCellNum();j++) {
                        cell=row.getCell(j);
                        if(j==0) {
                            col1=cell.getStringCellValue();
                            List<String> lst=new ArrayList<String>();
                            lst.add(col1);

                           cell=row.createCell(1);
                            CellType cell_Type=cell.getCellType();
                            System.out.print("CellTyepe"+cell_Type);
                            //cell.setCellType(cell_Type);
                            cell.setCellValue((String) col2_Value);
                        }
//                        if(j==1) {
//                            col2=cell.getStringCellValue();
//                        }
                    }
                    System.out.print("Col1"+col1);
                    FileOutputStream os=new FileOutputStream(path);
                    wb.write(os);
                    os.close();

                }
            } catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        }
    }
}

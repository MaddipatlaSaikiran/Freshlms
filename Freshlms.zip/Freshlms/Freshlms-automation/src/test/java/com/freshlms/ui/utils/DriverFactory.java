package com.freshlms.ui.utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import com.thoughtworks.xstream.InitializationException;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.net.MalformedURLException;

public class DriverFactory {
    static String Scenario_Name;
    private static WebDriver driver = null;





    public static WebDriver createAndGetDeviceDriver() throws MalformedURLException {
        try{

            WebDriverManager.chromedriver().setup();
            driver= new ChromeDriver();

        }catch (Exception e){

        }
        return driver;

    }

}

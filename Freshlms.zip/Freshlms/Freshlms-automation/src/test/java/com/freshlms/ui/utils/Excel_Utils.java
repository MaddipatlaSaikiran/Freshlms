package com.freshlms.ui.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class Excel_Utils {
    String path="C:\\Users\\mkiran8\\Desktop\\Freshlms\\Demo.xlsx";

    public static void read_excel_data(String path,String sheetName,int rowNum,int cellNum){
        String data="";
        try{
            FileInputStream inputStream=new FileInputStream(path);




        }catch (Exception e){

        }

    }




}

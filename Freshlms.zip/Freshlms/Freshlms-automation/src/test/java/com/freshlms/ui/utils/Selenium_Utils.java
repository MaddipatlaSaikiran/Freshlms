package com.freshlms.ui.utils;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Selenium_Utils {

    public WebDriver driver=null;
    // Timeouts for each WebDriverWait object, in seconds.


    public Selenium_Utils(){
        try{
            if (driver == null) {
                driver = DriverFactory.createAndGetDeviceDriver();
                driver.manage().window().maximize();
                PageFactory.initElements(driver, this);
            }

        }catch (Exception e){
            // Something went wrong during driver creation, return a failure
            e.printStackTrace();
            Assert.fail("Exception occurred instantiating PageObjectBase.driver [" + e.getMessage() + "]");

        }


    }

}
